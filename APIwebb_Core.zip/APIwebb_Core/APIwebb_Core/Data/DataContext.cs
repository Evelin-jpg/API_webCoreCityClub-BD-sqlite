﻿using Microsoft.EntityFrameworkCore;

namespace APIwebb_Core.Data
{

    public class DataContext : DbContext
    {

        public DataContext(DbContextOptions<DataContext> options) : base(options) 
        {
        
        }
        public DbSet<Membresium> Membresia => Set<Membresium>();

        public DbSet<Productium> Producto => Set<Productium>();

        public DbSet<Socium> Socio => Set<Socium>();

        public DbSet<Usuarium> Usuario => Set<Usuarium>();




    }

}
