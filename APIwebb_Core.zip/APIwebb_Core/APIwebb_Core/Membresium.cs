﻿using System.ComponentModel.DataAnnotations;

namespace APIwebb_Core
{
    public class Membresium
    {
        [Key]
        public int IDMembresia { get; set; }
        public string Numero { get; set; }
        public string Tipo { get; set; }
        public int Premia { get; set; }
        public int Status { get; set; } // Cambiado a Status, siguiendo las convenciones de nombres
    }
}

