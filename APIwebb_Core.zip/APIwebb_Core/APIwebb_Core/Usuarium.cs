﻿using System.ComponentModel.DataAnnotations;

namespace APIwebb_Core
{
    public class Usuarium
    {
        [Key]
        public int IDUsuario { get; set; }
        public string NumEmpleado { get; set; }
        public string Nombre { get; set; }
        public string Contrasena { get; set; }
        public bool Status { get; set; } // Cambiado a Status, siguiendo las convenciones de nombres
    }
}
