﻿using System.ComponentModel.DataAnnotations;

namespace APIwebb_Core
{
    public class Productium
    {
        [Key]
        public int IDProducto { get; set; }
        public string Clave { get; set; }
        public string Nombre { get; set; }
        public string Precio { get; set; }
        public string Cantidad { get; set; }
        public int Status { get; set; } // Cambiado a Status, siguiendo las convenciones de nombres
    }
}
