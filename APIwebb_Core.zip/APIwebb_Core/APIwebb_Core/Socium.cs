﻿using System.ComponentModel.DataAnnotations;

namespace APIwebb_Core
{
    public class Socium
    {
        [Key]
        public int IDSocio { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string FechaIngreso { get; set; }
        public int Status { get; set; } // Cambiado a Status, siguiendo las convenciones de nombres
    }
}
