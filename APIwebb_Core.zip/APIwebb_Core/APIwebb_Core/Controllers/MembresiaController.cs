﻿using APIwebb_Core.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APIwebb_Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MembresiaController : ControllerBase
    {
        private readonly DataContext _context;

        public MembresiaController(DataContext context) 
        {
            _context = context;
        
        }

        [HttpPost]
        public async Task<ActionResult<List<Membresium>>> AddCharacter(Membresium Membresia)
        {
            _context.Membresia.Add(Membresia);
            await _context.SaveChangesAsync();

            return Ok(await _context.Membresia.ToListAsync());
        }
        [HttpGet]
        public async Task<ActionResult<List<Membresium>>> GetAllCaracters()
        {
            return Ok(await _context.Membresia.ToListAsync());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Membresium>> GetCharacter(int id)
        {
            var articulo = await _context.Membresia.FindAsync(id);
            if (articulo == null)
            {
                return BadRequest("articulo no encontrado");
            }
            return Ok(articulo);
        }
        [HttpPut("{id}")]
        public async Task<ActionResult<Membresium>> UpdateArticulo(int id, Membresium Membresia)
        {
            var articuloToUpdate = await _context.Membresia.FindAsync(id);
            if (articuloToUpdate == null)
            {
                return NotFound("Artículo no encontrado");
            }
            articuloToUpdate.Numero = Membresia.Numero;
            articuloToUpdate.Tipo = Membresia.Tipo;
            articuloToUpdate.Premia = Membresia.Premia;
            articuloToUpdate.Status = Membresia.Status;

            _context.Membresia.Update(articuloToUpdate);
            await _context.SaveChangesAsync();

            return Ok(articuloToUpdate);
        }
        [HttpPut("inactivar/{id}")]
        public async Task<ActionResult> InactivarMembresia(int id)
        {
            var articulo = await _context.Membresia.FindAsync(id);
            if (articulo == null)
            {
                return NotFound("Artículo no encontrado");
            }

            articulo.Status = 0;


            _context.Membresia.Update(articulo);
            await _context.SaveChangesAsync();

            return Ok("Artículo inactivado correctamente");
        }

        [HttpGet("GetActiveMembresias")]
        public async Task<ActionResult<IEnumerable<Membresium>>> GetActiveMembresias()
        {
            return await _context.Membresia.Where(m => m.Status == 1).ToListAsync();
        }
    }
}
