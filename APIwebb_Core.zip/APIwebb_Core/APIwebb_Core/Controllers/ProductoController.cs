﻿using APIwebb_Core.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace APIwebb_Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ProductoController : ControllerBase
    {
        private readonly DataContext _context;

        public ProductoController(DataContext context)
        {
            _context = context;

        }

        [HttpPost]
        public async Task<ActionResult<List<Productium>>> AddCharacter(Productium Producto)
        {
            _context.Producto.Add(Producto);
            await _context.SaveChangesAsync();

            return Ok(await _context.Producto.ToListAsync());
        }
        [HttpGet]
        public async Task<ActionResult<List<Productium>>> GetAllCaracters()
        {
            return Ok(await _context.Producto.ToListAsync());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Productium>> GetCharacter(int id)
        {
            var articulo = await _context.Producto.FindAsync(id);
            if (articulo == null)
            {
                return BadRequest("articulo no encontrado");
            }
            return Ok(articulo);
        }
        [HttpPut("{id}")]
        public async Task<ActionResult<Productium>> UpdateArticulo(int id, Productium Producto)
        {
            var articuloToUpdate = await _context.Producto.FindAsync(id);
            if (articuloToUpdate == null)
            {
                return NotFound("Artículo no encontrado");
            }
            articuloToUpdate.Clave = Producto.Clave;
            articuloToUpdate.Nombre = Producto.Nombre;
            articuloToUpdate.Precio = Producto.Precio;
            articuloToUpdate.Cantidad = Producto.Cantidad;
            articuloToUpdate.Status = Producto.Status;

            _context.Producto.Update(articuloToUpdate);
            await _context.SaveChangesAsync();

            return Ok(articuloToUpdate);
        }
        [HttpPut("inactivar/{id}")]
        public async Task<ActionResult> InactivarProducto(int id)
        {
            var articulo = await _context.Producto.FindAsync(id);
            if (articulo == null)
            {
                return NotFound("Artículo no encontrado");
            }

            articulo.Status = 0;


            _context.Producto.Update(articulo);
            await _context.SaveChangesAsync();

            return Ok("Artículo inactivado correctamente");
        }

        [HttpGet("GetActiveProductos")]
        public async Task<ActionResult<IEnumerable<Productium>>> GetActiveProductos()
        {
            return await _context.Producto.Where(m => m.Status == 1).ToListAsync();
        }
    }
}
