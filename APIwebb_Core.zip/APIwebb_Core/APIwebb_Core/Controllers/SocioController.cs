﻿using APIwebb_Core.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace APIwebb_Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SocioController : ControllerBase
    {
        private readonly DataContext _context;

        public SocioController(DataContext context)
        {
            _context = context;

        }

        [HttpPost]
        public async Task<ActionResult<List<Socium>>> AddCharacter(Socium Socio)
        {
            _context.Socio.Add(Socio);
            await _context.SaveChangesAsync();

            return Ok(await _context.Socio.ToListAsync());
        }
        [HttpGet]
        public async Task<ActionResult<List<Socium>>> GetAllCaracters()
        {
            return Ok(await _context.Socio.ToListAsync());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Socium>> GetCharacter(int id)
        {
            var socio = await _context.Socio.FindAsync(id);
            if (socio == null)
            {
                return BadRequest("socio no encontrado");
            }
            return Ok(socio);
        }
        [HttpPut("{id}")]
        public async Task<ActionResult<Socium>> UpdateSocio(int id, Socium Socio)
        {
            var SocioToUpdate = await _context.Socio.FindAsync(id);
            if (SocioToUpdate == null)
            {
                return NotFound("Socio no encontrado");
            }
            SocioToUpdate.Nombre = Socio.Nombre;
            SocioToUpdate.Telefono = Socio.Telefono;
            SocioToUpdate.FechaIngreso = Socio.FechaIngreso;
            SocioToUpdate.Status = Socio.Status;

            _context.Socio.Update(SocioToUpdate);
            await _context.SaveChangesAsync();

            return Ok(SocioToUpdate);
        }
        [HttpPut("inactivar/{id}")]
        public async Task<ActionResult> InactivarSocio(int id)
        {
            var socio = await _context.Socio.FindAsync(id);
            if (socio == null)
            {
                return NotFound("Socio no encontrado");
            }

            socio.Status = 0;


            _context.Socio.Update(socio);
            await _context.SaveChangesAsync();

            return Ok("Socio inactivado correctamente");
        }

        [HttpGet("GetActiveSocios")]
        public async Task<ActionResult<IEnumerable<Socium>>> GetActiveSocios()
        {
            return await _context.Socio.Where(m => m.Status == 1).ToListAsync();
        }
    }

}
